//package Example;
import java.util.*;

public interface Animado {
    abstract void acao();
}

