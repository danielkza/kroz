//package Example;
import java.util.*;
import java.io.*;

public class Motor  {
    static Jogo G;

    public Motor() {
		G = new Jogo();
		G.Av.DescreveLocal();
    }
	
    static public void main(String[] args) throws Exception {
		Motor m = new Motor();

    }
	
    static void Titulo(String s, String t) {
	}
	
    static void Status() {
		String s = G.Status.getLonga();
    }
	
    static void Inventario() {
    }
	
    static void Alerta(String s) {
    }
	
    static void Mostra(String s) {
    }
}
