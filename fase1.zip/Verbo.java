//package Example;
import java.util.*;
import java.io.*;

public class Verbo {
    void acao() {
		//Motor.Mostra("Hein???");
    }
    void acao(Elemento o) {
		//Motor.Mostra("Hein???");
    }
    void acao(Elemento o, Elemento oi) { 
		//Motor.Mostra("Hein???");
    }
    public String getNome() {
		return "???";
    }
}

